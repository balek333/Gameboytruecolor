# Game Boy TrueColor Camera — V1

Application Android native et **hors ligne** permettant de prendre des photos en :

- **128 x 112 px** (résolution de la Game Boy Camera)
- **160 x 144 px** (résolution de l'écran Game Boy)
- **Couleurs RVB 8 bits/canal** (TrueColor : 16,7 millions de couleurs possibles)
- **PNG sans pertes**, sauvegardés sous `Pictures/GBTrueColor` dans la galerie.

Le capteur produit une photo normale que l'application **recadre au centre et réduit réellement** ; aucune grille ni palette vintage n'est ajoutée. Le viseur de cette V1 n'est pas encore pixelisé en direct. La miniature de la dernière photo est affichée sans interpolation.

## Méthode recommandée : dépôt GitHub avec les fichiers du projet

1. Décompresser l'archive du projet sur un ordinateur.
2. Mettre **les fichiers contenus dans le dossier** à la racine d'un dépôt GitHub (pas le dossier parent).
3. Aller dans l'onglet **Actions** > **Compiler l'APK Game Boy TrueColor** > **Run workflow**.
4. Après la compilation, ouvrir l'exécution et télécharger l'artefact `GameBoyTrueColor-V1-APK`.
5. Extraire l'archive d'artefact : elle contient `app-debug.apk`, à installer sur le téléphone.

## Option mobile : dépôt contenant uniquement le ZIP et un workflow

Si tu utilises directement Chrome sur ton téléphone, tu peux également :

1. Télécharger `GameBoyTrueColor-V1-source.zip` et l'envoyer tel quel à la racine d'un dépôt GitHub.
2. Créer le fichier `.github/workflows/build-apk.yml` dans le dépôt depuis GitHub > Add file > Create new file.
3. Copier le contenu du fichier `build-apk-mobile.yml` fourni séparément, puis lancer l'action depuis l'onglet Actions.

Cette seconde méthode extrait l'archive pendant la compilation.

## Technique

- Kotlin, CameraX 1.6.2
- Android SDK 36, minSdk 29 (Android 10), targetSdk 34
- AGP 8.13.2, Gradle 8.13, Java 17
- Aucune autorisation stockage requise sur Android 10+ : MediaStore et dossier Pictures/GBTrueColor
- Aucune API externe, aucun compte, aucun abonnement

**Limite actuelle :** le projet est fourni comme source compilable, mais n'a pas été exécuté ni validé sur un téléphone réel dans cet environnement. La première compilation GitHub servira de contrôle d'intégration.

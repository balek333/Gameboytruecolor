package com.gbtruecolor.camera

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.drawable.BitmapDrawable
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Appareil photo minimal sans abonnement ni serveur.
 * Les images sont réellement réduites, puis sauvegardées en PNG opaque RVB 8+8+8 bits.
 * V1 : le viseur reste non pixelisé ; la miniature après capture montre le résultat.
 */
class MainActivity : ComponentActivity() {
    private val ioExecutor = Executors.newSingleThreadExecutor()
    private lateinit var cameraView: PreviewView
    private lateinit var statusView: TextView
    private lateinit var thumbnailView: ImageView
    private lateinit var cameraModeButton: Button
    private lateinit var gameBoyModeButton: Button
    private lateinit var shutterButton: Button

    @Volatile private var widthPx = 160
    @Volatile private var heightPx = 144
    private var imageCapture: ImageCapture? = null

    private val requestCameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startCamera()
        else statusView.text = "Autorise l'accès caméra dans les réglages Android."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(15, 20, 28)
        window.navigationBarColor = Color.rgb(15, 20, 28)
        createLayout()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) {
            startCamera()
        } else {
            requestCameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    private fun createLayout() {
        val background = Color.rgb(15, 20, 28)
        val foreground = Color.rgb(243, 243, 233)
        val accent = Color.rgb(235, 184, 95)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(background)
            setPadding(dp(14), dp(14), dp(14), dp(20))
        }

        root.addView(TextView(this).apply {
            text = "GB TRUECOLOR CAMERA"
            textSize = 20f
            setTextColor(accent)
            gravity = Gravity.CENTER
            setPadding(0, dp(7), 0, dp(10))
        })

        val frame = FrameLayout(this)
        cameraView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.BLACK)
        }
        frame.addView(
            cameraView,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )

        thumbnailView = ImageView(this).apply {
            visibility = View.GONE
            setBackgroundColor(Color.BLACK)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Dernière photo pixelisée"
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        frame.addView(
            thumbnailView,
            FrameLayout.LayoutParams(dp(126), dp(120), Gravity.BOTTOM or Gravity.START).apply {
                leftMargin = dp(10)
                bottomMargin = dp(10)
            }
        )
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))

        root.addView(TextView(this).apply {
            text = "CHOISIS LA RÉSOLUTION"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(foreground)
            setPadding(0, dp(17), 0, dp(7))
        })

        val modes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        cameraModeButton = Button(this).apply {
            text = "128 × 112\nGB Camera"
            isAllCaps = false
            textSize = 13f
            setOnClickListener { selectResolution(128, 112) }
        }
        gameBoyModeButton = Button(this).apply {
            text = "160 × 144\nGame Boy"
            isAllCaps = false
            textSize = 13f
            setOnClickListener { selectResolution(160, 144) }
        }
        modes.addView(cameraModeButton, LinearLayout.LayoutParams(0, dp(72), 1f))
        modes.addView(gameBoyModeButton, LinearLayout.LayoutParams(0, dp(72), 1f))
        root.addView(modes)

        shutterButton = Button(this).apply {
            text = "●  PRENDRE UNE PHOTO"
            isAllCaps = false
            textSize = 17f
            setTextColor(Color.rgb(16, 20, 27))
            backgroundTintList = android.content.res.ColorStateList.valueOf(accent)
            setOnClickListener { takePhoto() }
        }
        root.addView(shutterButton, LinearLayout.LayoutParams(-1, dp(70)))

        statusView = TextView(this).apply {
            text = "PNG TrueColor · sans filtre · hors ligne"
            textSize = 12f
            setTextColor(foreground)
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, 0)
        }
        root.addView(statusView)
        setContentView(root)
        selectResolution(160, 144)
    }

    private fun selectResolution(width: Int, height: Int) {
        widthPx = width
        heightPx = height
        val selected = android.content.res.ColorStateList.valueOf(Color.rgb(235, 184, 95))
        val unselected = android.content.res.ColorStateList.valueOf(Color.rgb(65, 72, 84))
        cameraModeButton.backgroundTintList = if (width == 128) selected else unselected
        gameBoyModeButton.backgroundTintList = if (width == 160) selected else unselected
        statusView.text = "Sortie PNG : ${width} × ${height} pixels · 24 bits RVB"
    }

    private fun startCamera() {
        statusView.text = "Initialisation de la caméra…"
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                val preview = Preview.Builder().build().also {
                    it.surfaceProvider = cameraView.surfaceProvider
                }
                val capture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .setOutputFormat(ImageCapture.OUTPUT_FORMAT_JPEG)
                    .build()
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, capture)
                imageCapture = capture
                statusView.text = "Prête · ${widthPx} × ${heightPx} · PNG RVB"
            } catch (exc: Exception) {
                statusView.text = "Caméra indisponible : ${exc.localizedMessage}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val capture = imageCapture ?: run {
            statusView.text = "La caméra n'est pas encore prête."
            return
        }
        val chosenWidth = widthPx
        val chosenHeight = heightPx
        shutterButton.isEnabled = false
        statusView.text = "Prise de vue…"

        capture.takePicture(ioExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    val original = decodeAndOrient(image)
                    val png = reducePhoto(original, chosenWidth, chosenHeight)
                    original.recycle()
                    val fileName = "GBTC_${chosenWidth}x${chosenHeight}_" +
                        SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.ROOT).format(Date()) + ".png"
                    savePng(png, fileName)
                    runOnUiThread {
                        // La miniature n'est pas enregistrée avec une fausse grille.
                        thumbnailView.setImageDrawable(
                            BitmapDrawable(resources, png).apply { setFilterBitmap(false) }
                        )
                        thumbnailView.visibility = View.VISIBLE
                        statusView.text = "✓ Enregistrée dans Images / GBTrueColor : $fileName"
                        shutterButton.isEnabled = true
                    }
                } catch (exc: Exception) {
                    runOnUiThread {
                        statusView.text = "Erreur : ${exc.localizedMessage ?: "impossible d'enregistrer"}"
                        shutterButton.isEnabled = true
                    }
                } finally {
                    image.close()
                }
            }

            override fun onError(exception: ImageCaptureException) {
                runOnUiThread {
                    statusView.text = "Capture impossible : ${exception.localizedMessage}"
                    shutterButton.isEnabled = true
                }
            }
        })
    }

    private fun decodeAndOrient(image: ImageProxy): Bitmap {
        val buffer = image.planes.first().buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        val raw = BitmapFactory.decodeByteArray(
            bytes, 0, bytes.size,
            BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 }
        ) ?: error("Décodage de la photo impossible")
        val rotation = image.imageInfo.rotationDegrees
        if (rotation == 0) return raw
        val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
        val oriented = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, matrix, true)
        if (oriented !== raw) raw.recycle()
        return oriented
    }

    private fun reducePhoto(source: Bitmap, targetW: Int, targetH: Int): Bitmap {
        val targetRatio = targetW.toDouble() / targetH
        val sourceRatio = source.width.toDouble() / source.height
        val cropW: Int
        val cropH: Int
        if (sourceRatio > targetRatio) {
            cropH = source.height
            cropW = (cropH * targetRatio).toInt().coerceIn(1, source.width)
        } else {
            cropW = source.width
            cropH = (cropW / targetRatio).toInt().coerceIn(1, source.height)
        }
        val x = (source.width - cropW) / 2
        val y = (source.height - cropH) / 2
        val cropped = Bitmap.createBitmap(source, x, y, cropW, cropH)
        // Rééchantillonnage réel de l'image : aucune grille superposée.
        val small = Bitmap.createScaledBitmap(cropped, targetW, targetH, true)
        if (cropped !== source && cropped !== small) cropped.recycle()
        val opaque = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888)
        opaque.setHasAlpha(false)
        val canvas = android.graphics.Canvas(opaque)
        canvas.drawColor(Color.BLACK)
        canvas.drawBitmap(small, 0f, 0f, null)
        if (small !== opaque) small.recycle()
        return opaque
    }

    private fun savePng(image: Bitmap, name: String) {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/GBTrueColor")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("Impossible de créer le fichier dans la galerie")
        try {
            contentResolver.openOutputStream(uri)?.use { out ->
                check(image.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                    "Écriture du PNG impossible"
                }
            } ?: error("Impossible d'ouvrir le fichier PNG")
            val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
            contentResolver.update(uri, done, null, null)
        } catch (exc: Exception) {
            contentResolver.delete(uri, null, null)
            throw exc
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        ioExecutor.shutdown()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density + 0.5f).toInt()
}
